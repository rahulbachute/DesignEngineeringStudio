class SubmissionsBrowser {
  constructor() {
    this.data = [];
    this.filteredData = [];
    this.currentPage = 1;
    this.pageSize = 10;
    this.sortField = 'submittedOn';
    this.sortDirection = 'desc';
    this.elements = {
      form: document.getElementById('submissionFilters'),
      tableBody: document.getElementById('submissionTableBody'),
      pagination: document.getElementById('paginationControls'),
      summary: document.getElementById('submissionSummary'),
      challengeFilter: document.getElementById('challengeFilter'),
      branchFilter: document.getElementById('branchFilter'),
      divisionFilter: document.getElementById('divisionFilter'),
      studentNameFilter: document.getElementById('studentNameFilter'),
      prnFilter: document.getElementById('prnFilter'),
      statusFilter: document.getElementById('statusFilter'),
      attemptFilter: document.getElementById('attemptFilter'),
      dateFromFilter: document.getElementById('dateFromFilter'),
      dateToFilter: document.getElementById('dateToFilter'),
      resetButton: document.getElementById('resetFilters'),
      detailsModal: document.getElementById('submissionDetailsModal'),
      detailsContent: document.getElementById('submissionDetailsContent'),
      launchEvaluationButton: document.getElementById('launchEvaluationButton'),
      evaluationModal: document.getElementById('evaluationWorkspaceModal'),
      evaluationContent: document.getElementById('evaluationWorkspaceContent'),
      saveEvaluationButton: document.getElementById('saveEvaluationButton')
    };
  }

  init() {
    this.bindEvents();
    this.showLoadingState();
    this.loadData();
  }

  async loadData() {
    try {
      const items = await DESSubmissionService.getSubmissions();
      this.data = items.map((item) => (item instanceof SubmissionModel ? item : new SubmissionModel(item)));
      this.populateFilters();
      this.applyFilters();
    } catch (error) {
      this.showError(error.message || 'Unable to load submissions from the data layer.');
    }
  }

  bindEvents() {
    this.elements.form.addEventListener('submit', (event) => {
      event.preventDefault();
      this.currentPage = 1;
      this.applyFilters();
    });

    this.elements.resetButton.addEventListener('click', () => {
      this.elements.form.reset();
      this.currentPage = 1;
      this.applyFilters();
    });

    document.querySelectorAll('[data-sort]').forEach((button) => {
      button.addEventListener('click', () => {
        const field = button.dataset.sort;
        if (this.sortField === field) {
          this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
        } else {
          this.sortField = field;
          this.sortDirection = 'desc';
        }
        this.applyFilters();
      });
    });

    this.elements.tableBody.addEventListener('click', (event) => {
      const actionButton = event.target.closest('[data-action]');
      if (!actionButton) {
        return;
      }

      const record = this.data.find((item) => item.id === Number(actionButton.dataset.id));
      if (!record) {
        return;
      }

      const action = actionButton.dataset.action;
      if (action === 'view') {
        this.openDetailsModal(record);
      } else if (action === 'evaluate') {
        this.openEvaluationModal(record);
      } else if (action === 'export') {
        this.showPlaceholderNotice('PDF export is a placeholder for the next integration sprint.');
      }
    });

    this.elements.launchEvaluationButton.addEventListener('click', () => {
      const record = this.currentDetailsRecord;
      if (record) {
        this.openEvaluationModal(record);
      }
    });

    this.elements.saveEvaluationButton.addEventListener('click', async () => {
      try {
        await DESSubmissionService.saveEvaluation({
          submissionId: this.currentDetailsRecord?.id || 0,
          status: 'draft',
          savedAt: new Date().toISOString()
        });
        const modalInstance = bootstrap.Modal.getInstance(this.elements.evaluationModal);
        if (modalInstance) {
          modalInstance.hide();
        }
        this.showPlaceholderNotice('Evaluation saved through the service layer.');
      } catch (error) {
        this.showPlaceholderNotice(error.message || 'Evaluation save failed.');
      }
    });

    this.elements.pagination.addEventListener('click', (event) => {
      const button = event.target.closest('button[data-page]');
      if (!button) {
        return;
      }

      const pageNumber = Number(button.dataset.page);
      if (!Number.isNaN(pageNumber)) {
        this.currentPage = pageNumber;
        this.renderTable();
        this.renderPagination();
      }
    });
  }

  populateFilters() {
    const challenges = [...new Set(this.data.map((item) => item.challenge))].sort();
    const branches = [...new Set(this.data.map((item) => item.branch))].sort();
    const divisions = [...new Set(this.data.map((item) => item.division))].sort();

    this.populateSelect(this.elements.challengeFilter, challenges, 'All Challenges');
    this.populateSelect(this.elements.branchFilter, branches, 'All Branches');
    this.populateSelect(this.elements.divisionFilter, divisions, 'All Divisions');
  }

  populateSelect(selectElement, values, placeholder) {
    const fragment = document.createDocumentFragment();
    const placeholderOption = document.createElement('option');
    placeholderOption.value = '';
    placeholderOption.textContent = placeholder;
    fragment.appendChild(placeholderOption);

    values.forEach((value) => {
      const option = document.createElement('option');
      option.value = value;
      option.textContent = value;
      fragment.appendChild(option);
    });

    selectElement.innerHTML = '';
    selectElement.appendChild(fragment);
  }

  applyFilters() {
    const filters = this.getFilters();

    this.filteredData = this.data.filter((item) => {
      const challengeMatch = !filters.challenge || item.challenge === filters.challenge;
      const branchMatch = !filters.branch || item.branch === filters.branch;
      const divisionMatch = !filters.division || item.division === filters.division;
      const studentMatch = !filters.studentName || item.studentName.toLowerCase().includes(filters.studentName.toLowerCase());
      const prnMatch = !filters.prn || item.prn.toLowerCase().includes(filters.prn.toLowerCase());
      const statusMatch = !filters.status || item.submissionStatus === filters.status;
      const attemptMatch = !filters.attempt || String(item.attempt) === filters.attempt;
      const dateFromMatch = !filters.dateFrom || new Date(item.submittedOn) >= new Date(filters.dateFrom);
      const dateToMatch = !filters.dateTo || new Date(item.submittedOn) <= new Date(filters.dateTo);

      return challengeMatch && branchMatch && divisionMatch && studentMatch && prnMatch && statusMatch && attemptMatch && dateFromMatch && dateToMatch;
    });

    this.filteredData.sort((left, right) => {
      const leftValue = left[this.sortField];
      const rightValue = right[this.sortField];
      if (this.sortField === 'submittedOn') {
        const leftDate = new Date(leftValue);
        const rightDate = new Date(rightValue);
        return this.sortDirection === 'asc' ? leftDate - rightDate : rightDate - leftDate;
      }

      if (typeof leftValue === 'number' && typeof rightValue === 'number') {
        return this.sortDirection === 'asc' ? leftValue - rightValue : rightValue - leftValue;
      }

      const comparison = String(leftValue).localeCompare(String(rightValue));
      return this.sortDirection === 'asc' ? comparison : -comparison;
    });

    this.currentPage = Math.min(this.currentPage, Math.max(1, Math.ceil(this.filteredData.length / this.pageSize) || 1));
    this.renderSummary();
    this.renderTable();
    this.renderPagination();
  }

  getFilters() {
    const formData = new FormData(this.elements.form);
    return {
      challenge: formData.get('challenge') || '',
      branch: formData.get('branch') || '',
      division: formData.get('division') || '',
      studentName: formData.get('studentName') || '',
      prn: formData.get('prn') || '',
      status: formData.get('status') || '',
      attempt: formData.get('attempt') || '',
      dateFrom: formData.get('dateFrom') || '',
      dateTo: formData.get('dateTo') || ''
    };
  }

  renderSummary() {
    const total = this.filteredData.length;
    const from = total === 0 ? 0 : (this.currentPage - 1) * this.pageSize + 1;
    const to = Math.min(this.currentPage * this.pageSize, total);
    this.elements.summary.textContent = total === 0 ? 'No submissions match the current filters.' : `Showing ${from}-${to} of ${total} submissions`;
  }

  showLoadingState() {
    this.elements.summary.textContent = 'Loading submissions from the repository…';
    this.elements.tableBody.innerHTML = `
      <tr>
        <td colspan="11" class="text-center text-muted py-4">
          <div class="d-flex justify-content-center align-items-center gap-2">
            <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
            <span>Loading submissions…</span>
          </div>
        </td>
      </tr>
    `;
    this.elements.pagination.innerHTML = '';
  }

  showError(message) {
    this.elements.summary.textContent = message;
    this.elements.tableBody.innerHTML = `<tr><td colspan="11" class="text-center text-muted py-4">${this.escapeHtml(message)}</td></tr>`;
  }

  renderTable() {
    const start = (this.currentPage - 1) * this.pageSize;
    const pageItems = this.filteredData.slice(start, start + this.pageSize);

    if (!pageItems.length) {
      this.elements.tableBody.innerHTML = '<tr><td colspan="8" class="text-center text-muted py-4">No submissions available for the selected view.</td></tr>';
      return;
    }

    this.elements.tableBody.innerHTML = pageItems.map((item) => `
      <tr>
        <td>${this.escapeHtml(item.studentName)}</td>
        <td>${this.escapeHtml(item.prn)}</td>
        <td>${this.escapeHtml(item.branch)}</td>
        <td>${this.escapeHtml(item.division)}</td>
        <td>${this.escapeHtml(item.challenge)}</td>
        <td>${item.attempt}</td>
        <td>${this.escapeHtml(item.submittedOn)}</td>
        <td><span class="badge ${this.statusBadgeClass(item.submissionStatus)}">${this.escapeHtml(item.submissionStatus)}</span></td>
        <td>${item.systemScore !== null ? item.systemScore : '—'}</td>
        <td>${item.facultyScore !== null ? item.facultyScore : '—'}</td>
        <td>
          <div class="d-flex flex-wrap gap-2">
            <button type="button" class="btn btn-outline-primary btn-sm" data-action="view" data-id="${item.id}">View Submission</button>
            <button type="button" class="btn btn-outline-info btn-sm" data-action="evaluate" data-id="${item.id}">Start Evaluation</button>
            <button type="button" class="btn btn-outline-secondary btn-sm" data-action="export" data-id="${item.id}">Export PDF</button>
          </div>
        </td>
      </tr>
    `).join('');
  }

  renderPagination() {
    const totalPages = Math.max(1, Math.ceil(this.filteredData.length / this.pageSize));
    const items = [];

    items.push(`
      <li class="page-item ${this.currentPage === 1 ? 'disabled' : ''}">
        <button class="page-link" type="button" data-page="${Math.max(1, this.currentPage - 1)}">Previous</button>
      </li>
    `);

    for (let page = 1; page <= totalPages; page += 1) {
      items.push(`
        <li class="page-item ${page === this.currentPage ? 'active' : ''}">
          <button class="page-link" type="button" data-page="${page}">${page}</button>
        </li>
      `);
    }

    items.push(`
      <li class="page-item ${this.currentPage === totalPages ? 'disabled' : ''}">
        <button class="page-link" type="button" data-page="${Math.min(totalPages, this.currentPage + 1)}">Next</button>
      </li>
    `);

    this.elements.pagination.innerHTML = items.join('');
  }

  openDetailsModal(record) {
    this.currentDetailsRecord = record;
    const detailMarkup = `
      <div class="row g-4">
        <div class="col-lg-6">
          <div class="border rounded-4 p-3 h-100">
            <h4 class="h6 text-uppercase text-muted">Student Information</h4>
            <p class="mb-1"><strong>Name:</strong> ${this.escapeHtml(record.studentName)}</p>
            <p class="mb-1"><strong>PRN:</strong> ${this.escapeHtml(record.prn)}</p>
            <p class="mb-1"><strong>Branch:</strong> ${this.escapeHtml(record.branch)}</p>
            <p class="mb-0"><strong>Division:</strong> ${this.escapeHtml(record.division)}</p>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="border rounded-4 p-3 h-100">
            <h4 class="h6 text-uppercase text-muted">Challenge Information</h4>
            <p class="mb-1"><strong>Challenge:</strong> ${this.escapeHtml(record.challenge)}</p>
            <p class="mb-1"><strong>Submission Date:</strong> ${this.escapeHtml(record.submittedOn)}</p>
            <p class="mb-1"><strong>Attempt Number:</strong> ${record.attempt}</p>
            <p class="mb-0"><strong>Time Taken:</strong> ${this.escapeHtml(record.timeTaken)}</p>
          </div>
        </div>
        <div class="col-12">
          <div class="border rounded-4 p-3">
            <h4 class="h6 text-uppercase text-muted">Activity Summary</h4>
            <p class="mb-2"><strong>Submission Status:</strong> <span class="badge ${this.statusBadgeClass(record.submissionStatus)}">${this.escapeHtml(record.submissionStatus)}</span></p>
            <ul class="list-group list-group-flush">
              ${record.activities.map((activity) => `
                <li class="list-group-item px-0">
                  <div class="d-flex justify-content-between align-items-start gap-3">
                    <div>
                      <strong>${this.escapeHtml(activity.name)}</strong>
                      <p class="mb-0 text-muted">${this.escapeHtml(activity.response)}</p>
                    </div>
                    <span class="badge bg-light text-dark">${activity.maxMarks} marks</span>
                  </div>
                </li>
              `).join('')}
            </ul>
          </div>
        </div>
      </div>
    `;

    this.elements.detailsContent.innerHTML = detailMarkup;
    const modal = new bootstrap.Modal(this.elements.detailsModal);
    modal.show();
  }

  openEvaluationModal(record) {
    this.currentDetailsRecord = record;
    const evaluationMarkup = `
      <div class="row g-4">
        <div class="col-lg-6">
          <label class="form-label">Student Name</label>
          <input class="form-control" type="text" value="${this.escapeHtml(record.studentName)}" readonly />
        </div>
        <div class="col-lg-6">
          <label class="form-label">Challenge</label>
          <input class="form-control" type="text" value="${this.escapeHtml(record.challenge)}" readonly />
        </div>
        <div class="col-12">
          <label class="form-label">Activities</label>
          <div class="border rounded-4 p-3">
            <ul class="list-group list-group-flush">
              ${record.activities.map((activity) => `
                <li class="list-group-item px-0">
                  <div class="d-flex justify-content-between align-items-start gap-3">
                    <div>
                      <strong>${this.escapeHtml(activity.name)}</strong>
                      <p class="mb-0 text-muted">${this.escapeHtml(activity.response)}</p>
                    </div>
                    <span class="badge bg-light text-dark">${activity.maxMarks} max</span>
                  </div>
                </li>
              `).join('')}
            </ul>
          </div>
        </div>
        <div class="col-md-4">
          <label class="form-label">Maximum Marks</label>
          <input class="form-control" type="text" value="${record.activities.reduce((total, activity) => total + activity.maxMarks, 0)}" readonly />
        </div>
        <div class="col-md-4">
          <label class="form-label">System Suggested Marks (Placeholder)</label>
          <input class="form-control" type="text" value="${record.systemScore !== null ? record.systemScore : '—'}" readonly />
        </div>
        <div class="col-md-4">
          <label class="form-label">Faculty Marks (Editable Placeholder)</label>
          <input class="form-control" type="number" value="${record.facultyScore !== null ? record.facultyScore : ''}" />
        </div>
        <div class="col-12">
          <label class="form-label">Remarks</label>
          <textarea class="form-control" rows="3" placeholder="Add remarks for the evaluation workflow."></textarea>
        </div>
        <div class="col-md-4">
          <label class="form-label">Total Marks</label>
          <input class="form-control" type="text" value="TBD" readonly />
        </div>
      </div>
    `;

    this.elements.evaluationContent.innerHTML = evaluationMarkup;
    const modal = new bootstrap.Modal(this.elements.evaluationModal);
    modal.show();
  }

  showPlaceholderNotice(message) {
    const alert = document.createElement('div');
    alert.className = 'alert alert-info alert-dismissible fade show mt-3';
    alert.setAttribute('role', 'alert');
    alert.innerHTML = `${this.escapeHtml(message)}<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>`;
    const target = this.elements.tableBody.closest('.card-body');
    target.prepend(alert);
    setTimeout(() => {
      alert.remove();
    }, 2800);
  }

  statusBadgeClass(status) {
    const classes = {
      Submitted: 'bg-success-subtle text-success-emphasis',
      'Under Review': 'bg-info-subtle text-info-emphasis',
      Evaluated: 'bg-primary-subtle text-primary-emphasis',
      Returned: 'bg-warning-subtle text-warning-emphasis'
    };
    return classes[status] || 'bg-secondary-subtle text-secondary-emphasis';
  }

  escapeHtml(value) {
    return String(value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  generateMockData() {
    const challenges = [
      'Elevator Safety Verification',
      'Motorcycle Side Stand',
      'Bell Crank Lever',
      'Traction System Design',
      'Material Selection Review'
    ];

    const branches = ['Mechanical', 'Automobile', 'Mechatronics'];
    const divisions = ['A', 'B', 'C'];
    const students = [
      { name: 'Riya Kulkarni', prn: 'PRN21001' },
      { name: 'Arjun Shah', prn: 'PRN21002' },
      { name: 'Neha Patil', prn: 'PRN21003' },
      { name: 'Siddhesh Rao', prn: 'PRN21004' },
      { name: 'Aditi Joshi', prn: 'PRN21005' },
      { name: 'Kunal Bhosale', prn: 'PRN21006' },
      { name: 'Pooja Deshmukh', prn: 'PRN21007' },
      { name: 'Harsh Verma', prn: 'PRN21008' },
      { name: 'Tanvi More', prn: 'PRN21009' },
      { name: 'Omkar Pawar', prn: 'PRN21010' },
      { name: 'Sakshi Jadhav', prn: 'PRN21011' },
      { name: 'Mrunal Chavan', prn: 'PRN21012' },
      { name: 'Nikhil Ture', prn: 'PRN21013' },
      { name: 'Ishika Kale', prn: 'PRN21014' },
      { name: 'Aditya Nair', prn: 'PRN21015' },
      { name: 'Mansi Dhamale', prn: 'PRN21016' },
      { name: 'Pranav Sutar', prn: 'PRN21017' },
      { name: 'Sneha Inamdar', prn: 'PRN21018' },
      { name: 'Tejas Wagh', prn: 'PRN21019' },
      { name: 'Vaishnavi Borkar', prn: 'PRN21020' },
      { name: 'Aniket Shah', prn: 'PRN21021' },
      { name: 'Shreya Mirajkar', prn: 'PRN21022' },
      { name: 'Nilesh Gawade', prn: 'PRN21023' },
      { name: 'Rutuja Salunke', prn: 'PRN21024' },
      { name: 'Yash Mandke', prn: 'PRN21025' }
    ];

    const statuses = ['Submitted', 'Under Review', 'Evaluated', 'Returned'];
    const evaluations = ['Pending Review', 'Ready for Faculty', 'Ready for Final', 'Returned for Revision'];

    return students.map((student, index) => {
      const challenge = challenges[index % challenges.length];
      const branch = branches[index % branches.length];
      const division = divisions[index % divisions.length];
      const submissionStatus = statuses[index % statuses.length];
      const evaluationStatus = evaluations[index % evaluations.length];
      const attempt = (index % 3) + 1;
      const submittedOn = new Date(2026, 6, 15 + (index % 10)).toISOString().slice(0, 10);
      const activities = [
        {
          name: 'Problem Definition',
          response: 'Documented the design objective and constraints with clear assumptions.',
          maxMarks: 10
        },
        {
          name: 'Analysis and Calculations',
          response: 'Applied engineering principles and recorded relevant technical values.',
          maxMarks: 15
        },
        {
          name: 'Design Recommendation',
          response: 'Presented the recommended solution with supporting rationale.',
          maxMarks: 15
        }
      ];

      const systemScore = submissionStatus === 'Evaluated' ? 78 + (index % 4) : submissionStatus === 'Returned' ? 62 + (index % 3) : null;
      const facultyScore = submissionStatus === 'Evaluated' ? 80 + (index % 4) : submissionStatus === 'Returned' ? 64 + (index % 3) : null;

      return {
        id: index + 1,
        studentName: student.name,
        prn: student.prn,
        branch,
        division,
        challenge,
        attempt,
        submittedOn,
        evaluationStatus,
        submissionStatus,
        systemScore,
        facultyScore,
        timeTaken: `${45 + index % 20} mins`,
        activities
      };
    });
  }
}

document.addEventListener('DOMContentLoaded', () => {
  new SubmissionsBrowser().init();
});
