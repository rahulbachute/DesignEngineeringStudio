class AnalyticsEngine {
  constructor() {
    this.state = {
      metrics: null,
      chartInstances: {}
    };
  }

  async init() {
    this.bindEvents();
    this.renderFilters();
    this.renderLoadingState();
    try {
      const data = await DESAnalyticsService.getAnalytics();
      this.state.metrics = this.buildMetricsFromRepository(data);
      this.renderDashboard();
      this.renderCharts();
    } catch (error) {
      this.showToast(error.message || 'Unable to load analytics data.', true);
      this.renderErrorState();
    }
  }

  bindEvents() {
    const form = document.getElementById('analyticsFilters');
    if (!form) {
      return;
    }

    form.addEventListener('submit', (event) => {
      event.preventDefault();
      this.renderDashboard();
      this.renderCharts();
      this.showToast('Analytics refreshed for the selected view.');
    });

    document.getElementById('resetAnalyticsFilters').addEventListener('click', () => {
      form.reset();
      this.renderDashboard();
      this.renderCharts();
    });
  }

  renderFilters() {
    const options = {
      academicYearFilter: ['2025-26', '2026-27'],
      semesterFilter: ['Sem III', 'Sem IV'],
      programmeFilter: ['B.E. Mechanical'],
      departmentFilter: ['Mechanical Engineering'],
      facultyFilter: ['Dr. Rahul Bachute', 'Prof. A. Sharma'],
      batchFilter: ['Batch A', 'Batch B', 'Batch C'],
      divisionFilter: ['A', 'B', 'C'],
      challengeFilter: ['EC-01 Elevator Safety Verification', 'EC-02 Motorcycle Side Stand', 'EC-03 Bell Crank Lever']
    };

    Object.entries(options).forEach(([id, values]) => {
      const select = document.getElementById(id);
      if (!select) {
        return;
      }
      select.innerHTML = ['<option value="">All</option>', ...values.map((value) => `<option value="${this.escapeHtml(value)}">${this.escapeHtml(value)}</option>`)].join('');
    });

    const dateRange = document.getElementById('dateRangeFilter');
    if (dateRange) {
      dateRange.value = '2026-01-01 to 2026-07-31';
    }
  }

  buildMetricsFromRepository(data) {
    const summary = data?.summary || {};
    const insights = data?.insights || [];
    const recommendations = data?.recommendations || [];

    return {
      totalStudents: 148,
      totalChallenges: 9,
      completedEvaluations: 132,
      pendingEvaluations: 16,
      averageMarks: summary.averageMarks || 74.8,
      overallCOAttainment: 76,
      overallPOContribution: 79,
      overallStudentPerformance: 72,
      academicPerformance: {
        averageMarks: summary.averageMarks || 74.8,
        medianMarks: 76,
        highestMarks: 92,
        lowestMarks: 41,
        passPercentage: 88,
        gradeDistribution: { A: 24, B: 36, C: 22, D: 10, F: 8 },
        challengeDifficultyIndex: 68,
        challengeCompletionRate: 91,
        facultyEvaluationProgress: 84
      },
      studentPerformance: {
        topPerformingStudents: ['Riya Kulkarni', 'Aditi Joshi', 'Kunal Bhosale'],
        studentsNeedingImprovement: ['Harsh Verma', 'Mrunal Chavan', 'Nilesh Gawade'],
        attendancePlaceholder: '92%',
        submissionTimeliness: '87%',
        attemptAnalysis: '2.1 avg attempts',
        performanceTrend: '+6.4% vs previous cycle',
        learningProgress: 'Steady upward trend',
        riskIndicator: 'Moderate'
      },
      challengeAnalytics: {
        mostAttempted: 'EC-01 Elevator Safety Verification',
        leastAttempted: 'EC-03 Bell Crank Lever',
        highestAverageScore: 'EC-02 Motorcycle Side Stand',
        lowestAverageScore: 'EC-03 Bell Crank Lever',
        mostDifficult: 'EC-03 Bell Crank Lever',
        mostTimeConsuming: 'EC-01 Elevator Safety Verification',
        completionTrend: 'Rising',
        successRate: '86%'
      },
      facultyAnalytics: {
        evaluationsCompleted: 132,
        pendingReviews: 16,
        averageEvaluationTime: '14 mins',
        marksDistribution: { reviewed: 132, pending: 16 },
        activityTimeline: ['Review completed', 'Rubric updated', 'New batch received']
      },
      outcomeAnalytics: {
        coTrend: [78, 72, 69, 74, 82],
        poTrend: [81, 74, 65, 79, 77, 83, 72, 68, 76, 80, 70, 86],
        psoTrend: [82, 75, 69],
        wkTrend: [64, 81, 73, 58, 77, 68, 72, 66],
        heatmap: [['High', 'Moderate', 'Needs Improvement'], ['Moderate', 'High', 'Moderate'], ['High', 'Moderate', 'Low']]
      },
      insights: insights.length ? insights : [
        'CO2 attainment is below target and deserves focused review.',
        'Challenge EC-01 has the highest failure rate among current submissions.',
        'Students perform better in practical activities than in calculation-based ones.'
      ],
      recommendations: recommendations.length ? recommendations : [
        'Increase tutorial sessions for numerical and calculation-heavy activities.',
        'Provide a bridge course for learners needing remediation.'
      ]
    };
  }
    return {
      totalStudents: 148,
      totalChallenges: 9,
      completedEvaluations: 132,
      pendingEvaluations: 16,
      averageMarks: 74.8,
      overallCOAttainment: 76,
      overallPOContribution: 79,
      overallStudentPerformance: 72,
      academicPerformance: {
        averageMarks: 74.8,
        medianMarks: 76,
        highestMarks: 92,
        lowestMarks: 41,
        passPercentage: 88,
        gradeDistribution: { A: 24, B: 36, C: 22, D: 10, F: 8 },
        challengeDifficultyIndex: 68,
        challengeCompletionRate: 91,
        facultyEvaluationProgress: 84
      },
      studentPerformance: {
        topPerformingStudents: ['Riya Kulkarni', 'Aditi Joshi', 'Kunal Bhosale'],
        studentsNeedingImprovement: ['Harsh Verma', 'Mrunal Chavan', 'Nilesh Gawade'],
        attendancePlaceholder: '92%',
        submissionTimeliness: '87%',
        attemptAnalysis: '2.1 avg attempts',
        performanceTrend: '+6.4% vs previous cycle',
        learningProgress: 'Steady upward trend',
        riskIndicator: 'Moderate'
      },
      challengeAnalytics: {
        mostAttempted: 'EC-01 Elevator Safety Verification',
        leastAttempted: 'EC-03 Bell Crank Lever',
        highestAverageScore: 'EC-02 Motorcycle Side Stand',
        lowestAverageScore: 'EC-03 Bell Crank Lever',
        mostDifficult: 'EC-03 Bell Crank Lever',
        mostTimeConsuming: 'EC-01 Elevator Safety Verification',
        completionTrend: 'Rising',
        successRate: '86%'
      },
      facultyAnalytics: {
        evaluationsCompleted: 132,
        pendingReviews: 16,
        averageEvaluationTime: '14 mins',
        marksDistribution: { reviewed: 132, pending: 16 },
        activityTimeline: ['Review completed', 'Rubric updated', 'New batch received']
      },
      outcomeAnalytics: {
        coTrend: [78, 72, 69, 74, 82],
        poTrend: [81, 74, 65, 79, 77, 83, 72, 68, 76, 80, 70, 86],
        psoTrend: [82, 75, 69],
        wkTrend: [64, 81, 73, 58, 77, 68, 72, 66],
        heatmap: [['High', 'Moderate', 'Needs Improvement'], ['Moderate', 'High', 'Moderate'], ['High', 'Moderate', 'Low']]
      },
      insights: [
        'CO2 attainment is below target and deserves focused review.',
        'Challenge EC-01 has the highest failure rate among current submissions.',
        'Students perform better in practical activities than in calculation-based ones.',
        'Average evaluation time has reduced by 18% over the previous cycle.',
        'WK4 coverage needs improvement for stronger Washington Accord alignment.'
      ],
      recommendations: [
        'Increase tutorial sessions for numerical and calculation-heavy activities.',
        'Provide a bridge course for learners needing remediation.',
        'Conduct remedial classes for underperforming batches.',
        'Increase practical exposure in the next challenge cycle.'
      ]
    };
  }

  renderLoadingState() {
    document.getElementById('totalStudents').textContent = '…';
    document.getElementById('totalChallenges').textContent = '…';
    document.getElementById('completedEvaluations').textContent = '…';
    document.getElementById('pendingEvaluations').textContent = '…';
    document.getElementById('averageMarks').textContent = 'Loading…';
    document.getElementById('overallCOAttainment').textContent = 'Loading…';
    document.getElementById('overallPOContribution').textContent = 'Loading…';
    document.getElementById('overallStudentPerformance').textContent = 'Loading…';
  }

  renderErrorState() {
    document.getElementById('academicStats').innerHTML = '<div class="col-12 text-muted">Analytics data could not be loaded.</div>';
  }

  renderDashboard() {
    const metrics = this.state.metrics;
    document.getElementById('totalStudents').textContent = metrics.totalStudents;
    document.getElementById('totalChallenges').textContent = metrics.totalChallenges;
    document.getElementById('completedEvaluations').textContent = metrics.completedEvaluations;
    document.getElementById('pendingEvaluations').textContent = metrics.pendingEvaluations;
    document.getElementById('averageMarks').textContent = `${metrics.averageMarks.toFixed(1)}%`;
    document.getElementById('overallCOAttainment').textContent = `${metrics.overallCOAttainment}%`;
    document.getElementById('overallPOContribution').textContent = `${metrics.overallPOContribution}%`;
    document.getElementById('overallStudentPerformance').textContent = `${metrics.overallStudentPerformance}%`;

    document.getElementById('academicStats').innerHTML = [
      { label: 'Average Marks', value: `${metrics.academicPerformance.averageMarks}%` },
      { label: 'Median Marks', value: `${metrics.academicPerformance.medianMarks}%` },
      { label: 'Highest Marks', value: `${metrics.academicPerformance.highestMarks}%` },
      { label: 'Lowest Marks', value: `${metrics.academicPerformance.lowestMarks}%` },
      { label: 'Pass Percentage', value: `${metrics.academicPerformance.passPercentage}%` },
      { label: 'Challenge Difficulty Index', value: `${metrics.academicPerformance.challengeDifficultyIndex}` }
    ].map((item) => `
      <div class="col-md-4">
        <div class="border rounded-4 p-3 h-100">
          <p class="small text-muted mb-1">${this.escapeHtml(item.label)}</p>
          <h5 class="mb-0">${this.escapeHtml(item.value)}</h5>
        </div>
      </div>
    `).join('');

    document.getElementById('studentStats').innerHTML = [
      { label: 'Top Performing Students', value: metrics.studentPerformance.topPerformingStudents.join(', ') },
      { label: 'Needs Improvement', value: metrics.studentPerformance.studentsNeedingImprovement.join(', ') },
      { label: 'Attendance Placeholder', value: metrics.studentPerformance.attendancePlaceholder },
      { label: 'Submission Timeliness', value: metrics.studentPerformance.submissionTimeliness },
      { label: 'Attempt Analysis', value: metrics.studentPerformance.attemptAnalysis },
      { label: 'Learning Progress', value: metrics.studentPerformance.learningProgress }
    ].map((item) => `
      <div class="col-md-4">
        <div class="border rounded-4 p-3 h-100">
          <p class="small text-muted mb-1">${this.escapeHtml(item.label)}</p>
          <p class="mb-0">${this.escapeHtml(item.value)}</p>
        </div>
      </div>
    `).join('');

    document.getElementById('challengeStats').innerHTML = [
      { label: 'Most Attempted', value: metrics.challengeAnalytics.mostAttempted },
      { label: 'Least Attempted', value: metrics.challengeAnalytics.leastAttempted },
      { label: 'Highest Average Score', value: metrics.challengeAnalytics.highestAverageScore },
      { label: 'Lowest Average Score', value: metrics.challengeAnalytics.lowestAverageScore },
      { label: 'Most Difficult', value: metrics.challengeAnalytics.mostDifficult },
      { label: 'Completion Trend', value: metrics.challengeAnalytics.completionTrend }
    ].map((item) => `
      <div class="col-md-4">
        <div class="border rounded-4 p-3 h-100">
          <p class="small text-muted mb-1">${this.escapeHtml(item.label)}</p>
          <p class="mb-0">${this.escapeHtml(item.value)}</p>
        </div>
      </div>
    `).join('');

    document.getElementById('facultyStats').innerHTML = [
      { label: 'Evaluations Completed', value: metrics.facultyAnalytics.evaluationsCompleted },
      { label: 'Pending Reviews', value: metrics.facultyAnalytics.pendingReviews },
      { label: 'Average Evaluation Time', value: metrics.facultyAnalytics.averageEvaluationTime },
      { label: 'Marks Distribution', value: `${metrics.facultyAnalytics.marksDistribution.reviewed} reviewed / ${metrics.facultyAnalytics.marksDistribution.pending} pending` },
      { label: 'Faculty Activity Timeline', value: metrics.facultyAnalytics.activityTimeline.join(' • ') }
    ].map((item) => `
      <div class="col-md-4">
        <div class="border rounded-4 p-3 h-100">
          <p class="small text-muted mb-1">${this.escapeHtml(item.label)}</p>
          <p class="mb-0">${this.escapeHtml(item.value)}</p>
        </div>
      </div>
    `).join('');

    document.getElementById('outcomeStats').innerHTML = [
      { label: 'CO Trend', value: metrics.outcomeAnalytics.coTrend.join(' → ') },
      { label: 'PO Trend', value: metrics.outcomeAnalytics.poTrend.slice(0, 6).join(' → ') },
      { label: 'PSO Trend', value: metrics.outcomeAnalytics.psoTrend.join(' → ') },
      { label: 'WK Trend', value: metrics.outcomeAnalytics.wkTrend.join(' → ') }
    ].map((item) => `
      <div class="col-md-3">
        <div class="border rounded-4 p-3 h-100">
          <p class="small text-muted mb-1">${this.escapeHtml(item.label)}</p>
          <p class="mb-0">${this.escapeHtml(item.value)}</p>
        </div>
      </div>
    `).join('');

    document.getElementById('insightsList').innerHTML = metrics.insights.map((item) => `<li class="list-group-item">${this.escapeHtml(item)}</li>`).join('');
    document.getElementById('recommendationsList').innerHTML = metrics.recommendations.map((item) => `<li class="list-group-item">${this.escapeHtml(item)}</li>`).join('');
  }

  renderCharts() {
    this.destroyCharts();

    const gradeCtx = document.getElementById('gradeDistributionChart');
    if (gradeCtx) {
      this.state.chartInstances.grade = new Chart(gradeCtx, {
        type: 'doughnut',
        data: {
          labels: ['A', 'B', 'C', 'D', 'F'],
          datasets: [{ data: [24, 36, 22, 10, 8], backgroundColor: ['#2563eb', '#38bdf8', '#0f766e', '#f59e0b', '#ef4444'] }]
        },
        options: { responsive: true }
      });
    }

    const performanceTrendCtx = document.getElementById('performanceTrendChart');
    if (performanceTrendCtx) {
      this.state.chartInstances.performance = new Chart(performanceTrendCtx, {
        type: 'line',
        data: {
          labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul'],
          datasets: [{ label: 'Marks Trend', data: [68, 70, 71, 74, 76, 78, 81], borderColor: '#2563eb', fill: true, tension: 0.3 }]
        },
        options: { responsive: true }
      });
    }

    const challengeCtx = document.getElementById('challengeCompletionChart');
    if (challengeCtx) {
      this.state.chartInstances.challenge = new Chart(challengeCtx, {
        type: 'bar',
        data: {
          labels: ['EC-01', 'EC-02', 'EC-03'],
          datasets: [{ label: 'Completion Rate', data: [92, 88, 84], backgroundColor: ['#2563eb', '#10b981', '#f59e0b'] }]
        },
        options: { responsive: true }
      });
    }

    const facultyCtx = document.getElementById('facultyActivityChart');
    if (facultyCtx) {
      this.state.chartInstances.faculty = new Chart(facultyCtx, {
        type: 'bar',
        data: {
          labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
          datasets: [{ label: 'Reviews', data: [18, 22, 24, 21], backgroundColor: '#0f766e' }]
        },
        options: { responsive: true }
      });
    }

    const outcomeCtx = document.getElementById('outcomeTrendChart');
    if (outcomeCtx) {
      this.state.chartInstances.outcome = new Chart(outcomeCtx, {
        type: 'radar',
        data: {
          labels: ['CO', 'PO', 'PSO', 'WK'],
          datasets: [{ label: 'Outcome Balance', data: [76, 79, 75, 70], backgroundColor: 'rgba(37, 99, 235, 0.25)', borderColor: '#2563eb' }]
        },
        options: { responsive: true }
      });
    }

    const heatmapCtx = document.getElementById('heatmapChart');
    if (heatmapCtx) {
      this.state.chartInstances.heatmap = new Chart(heatmapCtx, {
        type: 'bar',
        data: {
          labels: ['CO1', 'CO2', 'CO3', 'CO4', 'CO5'],
          datasets: [{ label: 'Heatmap', data: [82, 70, 64, 58, 83], backgroundColor: ['#2563eb', '#38bdf8', '#f59e0b', '#ef4444', '#10b981'] }]
        },
        options: { responsive: true, plugins: { legend: { display: false } } }
      });
    }
  }

  destroyCharts() {
    Object.values(this.state.chartInstances).forEach((chart) => chart.destroy());
    this.state.chartInstances = {};
  }

  showToast(message) {
    const toast = document.createElement('div');
    toast.className = 'position-fixed top-0 end-0 m-3 toast align-items-center text-bg-success border-0 show';
    toast.setAttribute('role', 'alert');
    toast.innerHTML = `<div class="d-flex"><div class="toast-body">${this.escapeHtml(message)}</div><button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button></div>`;
    document.body.appendChild(toast);
    window.setTimeout(() => toast.remove(), 2400);
  }

  escapeHtml(value) {
    return String(value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }
}

document.addEventListener('DOMContentLoaded', () => {
  new AnalyticsEngine().init();
});
